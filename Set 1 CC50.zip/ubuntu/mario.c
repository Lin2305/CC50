#include <stdio.h>
#include <cs50.h>


int main (void){
         int x, i, j;

        do
        {
             x = get_int("Height: choose between 1 ~ 8\n");
        }
        while (x < 1 || x > 8);

       for (i = 0; i < x; i++)
            {
           for (j = 0; j < x; j++)
           {

               if(i + j < x - 1)
               {
                   printf(" ");
               }
               else
               printf("#");
           }
           printf("\n");
       }


}