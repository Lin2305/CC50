#include <stdio.h>
#include <cs50.h>
#include <math.h>

    int main(){
        
            int  i25, i10, i5, i1, centavos, moedas_totais;
            float valor; 
            
            i25 = 0; i10 = 0; i5 = 0; i1 = 0;
            do{
            valor = get_float("How much do we owe?: \n");
            } while (valor < 0);
            
             centavos = round(valor * 100);
             
             while (centavos >= 25)
             {
              centavos = centavos -25;
              i25++;
             }
              while (centavos >= 10)
              {
              centavos = centavos -10;
              i10++;
             }
              while (centavos >= 5)
              {
              centavos = centavos -5;
              i5++;
             }
              while (centavos >= 1)
              {
              centavos = centavos -1;
              i1++;
             }
           
             moedas_totais = i25+i10+i5+i1;
             printf("Total de Moedas:%i  \n", moedas_totais);
    }